export const environment = {
  production: true,
  stripeKey: 'pk_test_yL3DSrbEaoeHxTwRPmcZpxWj'
};
